#!/usr/bin/env python3
"""Photo Editor 2.0 - Main Window."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QFileDialog, QMainWindow, QMessageBox, QWidget, QVBoxLayout, QTabWidget, QSplitter

from config.defaults import DEFAULT_WINDOW_HEIGHT, DEFAULT_WINDOW_WIDTH
from config.version import WINDOW_TITLE
from core.canvas import Canvas
from core.catalog.photo import Photo
from core.adjustment_settings import AdjustmentSettings
from core.image_saver import ImageSaver
from ui.actions import ActionManager
from ui.dialogs import (
    AdjustmentsDialog,
    NewDocumentDialog,
    ResizeImageDialog,
)
from ui.layers_panel import LayersPanel
from ui.library.library_panel import LibraryPanel
from ui.library.folder_panel import FolderPanel
from ui.library.metadata_panel import MetadataPanel
from ui.develop.histogram_widget import HistogramWidget
from ui.develop.develop_panel import DevelopPanel
from ui.dock_widgets import DockWidget
from ui.menubar import MenuBar
from ui.statusbar import StatusBar
from ui.toolbar import ToolBar


class MainWindow(QMainWindow):
    """Main application window."""

    def __init__(self, catalog) -> None:
        super().__init__()

        self.catalog = catalog

        self.actions = ActionManager(self)

        self.canvas = Canvas(self)
        self.layers_panel = LayersPanel(self)
        self.folder_panel = FolderPanel(self)
        self.library_panel = LibraryPanel(self)
        self.metadata_panel = MetadataPanel()
        self.histogram_widget = HistogramWidget()
        self.develop_panel = DevelopPanel()

        self.tabs = QTabWidget(self)

        self.library_page = QWidget()
        self.library_layout = QVBoxLayout(self.library_page)
        self.library_layout.setContentsMargins(0, 0, 0, 0)

        self.library_splitter = QSplitter(Qt.Horizontal)

        self.library_splitter.addWidget(self.folder_panel)
        self.library_splitter.addWidget(self.library_panel)

        self.library_splitter.setStretchFactor(0, 1)
        self.library_splitter.setStretchFactor(1, 5)

        self.library_layout.addWidget(self.library_splitter)

        self.develop_page = QWidget()
        self.develop_layout = QVBoxLayout(self.develop_page)
        self.develop_layout.setContentsMargins(0, 0, 0, 0)
        self.develop_layout.addWidget(self.canvas)

        self.tabs.addTab(self.library_page, "Library")
        self.tabs.addTab(self.develop_page, "Develop")

        self._save_target_created = False

        self._build_window()
        self._create_connections()
        self._refresh_library()

    def _build_window(self) -> None:
        self.setWindowTitle(WINDOW_TITLE)
        self.resize(
            DEFAULT_WINDOW_WIDTH,
            DEFAULT_WINDOW_HEIGHT,
        )

        self.setMenuBar(MenuBar(self, self.actions))
        self.addToolBar(ToolBar(self, self.actions))

        self.status_bar = StatusBar(self)
        self.setStatusBar(self.status_bar)

        self.setCentralWidget(self.tabs)
        self.addDockWidget(
            Qt.RightDockWidgetArea,
            DockWidget("Warstwy", self.layers_panel, self),
        )

        self.addDockWidget(
            Qt.RightDockWidgetArea,
            DockWidget("Metadane", self.metadata_panel, self),
        )

        self.addDockWidget(
            Qt.RightDockWidgetArea,
            DockWidget("Histogram", self.histogram_widget, self),
        )
        self.status_bar.set_message("Gotowy")

    def _create_connections(self) -> None:
        self.actions.new.triggered.connect(
            self._new_document
        )
        self.actions.open.triggered.connect(
            self._open_image
        )
        self.actions.import_folder.triggered.connect(
            self._import_folder
        )
        self.actions.save.triggered.connect(
            self._save_image
        )
        self.actions.save_as.triggered.connect(
            self._save_image_as
        )
        self.actions.exit.triggered.connect(
            self.close
        )

        self.actions.zoom_in.triggered.connect(
            self.canvas.zoom_in
        )
        self.actions.zoom_out.triggered.connect(
            self.canvas.zoom_out
        )
        self.actions.fit.triggered.connect(
            self.canvas.fit_to_window
        )
        self.actions.actual_size.triggered.connect(
            self.canvas.actual_size
        )

        self.actions.undo.triggered.connect(
            self.canvas.undo
        )
        self.actions.redo.triggered.connect(
            self.canvas.redo
        )

        self.actions.resize_image.triggered.connect(
            self._resize_image
        )
        self.actions.adjustments.triggered.connect(
            self._adjust_image
        )

        self.actions.new_layer.triggered.connect(
            self._add_layer
        )

        self.actions.rotate_left.triggered.connect(
            self.canvas.rotate_left
        )
        self.actions.rotate_right.triggered.connect(
            self.canvas.rotate_right
        )

        self.actions.flip_horizontal.triggered.connect(
            self.canvas.flip_horizontal
        )
        self.actions.flip_vertical.triggered.connect(
            self.canvas.flip_vertical
        )

        self.actions.crop.toggled.connect(
            self._handle_crop_action_toggled
        )

        self.canvas.image_loaded.connect(
            self._handle_image_loaded
        )
        self.canvas.zoom_changed.connect(
            self.status_bar.set_zoom
        )
        self.canvas.crop_mode_changed.connect(
            self.actions.crop.setChecked
        )
        self.canvas.history_state_changed.connect(
            self._update_history_actions
        )

        self.layers_panel.layer_selected.connect(
            self._layer_selected
        )


        self.library_panel.photo_selected.connect(
            self._open_photo_from_library
        )

        self._update_history_actions(False, False)

    def _confirm_discard_changes(self) -> bool:
        """Ask what to do with unsaved changes."""

        if not self.canvas.document.modified:
            return True

        answer = QMessageBox.warning(
            self,
            "Niezapisane zmiany",
            (
                "Obraz został zmodyfikowany.\n\n"
                "Czy chcesz zapisać zmiany?"
            ),
            QMessageBox.StandardButton.Save
            | QMessageBox.StandardButton.Discard
            | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Save,
        )

        if answer == QMessageBox.StandardButton.Save:
            return self._save_image()

        if answer == QMessageBox.StandardButton.Discard:
            return True

        return False



    def _layer_selected(self, index: int) -> None:
        """Set the active layer."""

        document = self.canvas.document

        if not document.is_loaded:
            return

        document.layer_stack.set_active(index)
        self.canvas._refresh_canvas()



    def _open_photo_from_library(self, photo: Photo) -> None:
        """Open a photo selected in the Library."""

        self.canvas.load_image(photo.full_path)
        self.metadata_panel.set_photo(photo)
        self.develop_panel.load_photo(photo)
        self.tabs.setCurrentIndex(1)

    def _refresh_library(self) -> None:
        """Refresh library panel."""

        self.folder_panel.load_folders(
            self.catalog.folders()
        )

        self.library_panel.load_photos(
            self.catalog.photos()
        )

    def _refresh_layers_panel(self) -> None:
        """Refresh the layers panel."""

        self.layers_panel.set_layers(
            self.canvas.document.layer_stack.layer_names()
        )

    def _new_document(self) -> None:
        """Clear the current document."""

        if not self._confirm_discard_changes():
            return

        self.canvas.crop_tool.cancel()
        self.canvas.set_crop_selection_enabled(False)
        self.canvas.history.clear()
        dialog = NewDocumentDialog(self)

        if dialog.exec() != dialog.DialogCode.Accepted:
            return

        self.canvas.new_image(
            dialog.image_width,
            dialog.image_height,
            dialog.transparent_background,
        )

        self._save_target_created = False

        self._update_history_actions(False, False)
        self.status_bar.set_file_name("")
        self.status_bar.set_image_size(0, 0)
        self.status_bar.set_zoom(100.0)
        self._refresh_layers_panel()

        self.status_bar.set_message("Nowy dokument")


    def _add_layer(self) -> None:
        """Add a new layer to the current document."""

        document = self.canvas.document

        if not document.is_loaded:
            return

        document.add_layer()
        self._refresh_layers_panel()
        self.canvas._refresh_canvas()


    def _import_folder(self) -> None:
        """Import a folder into the catalog."""

        folder = QFileDialog.getExistingDirectory(
            self,
            "Importuj folder ze zdjęciami",
        )

        if not folder:
            return

        count = self.catalog.import_folder(Path(folder))

        self._refresh_library()

        QMessageBox.information(
            self,
            "Import zakończony",
            f"Zaimportowano {count} zdjęć.",
        )

    def _open_image(self) -> None:
        """Open an image after checking for unsaved changes."""

        if not self._confirm_discard_changes():
            return

        filename, _ = QFileDialog.getOpenFileName(
            self,
            "Otwórz obraz",
            "",
            (
                "Obrazy (*.jpg *.jpeg *.png *.webp *.bmp "
                "*.tif *.tiff *.nef *.cr2 *.cr3 *.arw "
                "*.dng *.orf *.rw2 *.raf *.pef);;"
                "Wszystkie pliki (*)"
            ),
        )

        if filename:
            self.canvas.load_image(filename)

    def _save_image(self) -> bool:
        """Save safely without overwriting the original image."""

        document = self.canvas.document

        if not document.is_loaded:
            return False

        if (
            not self._save_target_created
            or document.file_path is None
            or not ImageSaver.can_save(document.file_path)
        ):
            return self._save_image_as()

        if self.canvas.save_image():
            self._update_status_bar()
            self.status_bar.set_message("Obraz zapisany")
            return True

        QMessageBox.warning(
            self,
            "Photo Editor 2.0",
            "Nie udało się zapisać obrazu.",
        )
        return False

    def _save_image_as(self) -> bool:
        """Save the current image under a new file name."""

        document = self.canvas.document

        if not document.is_loaded:
            return False

        suggested_path = self._suggest_save_path()

        filename, _ = QFileDialog.getSaveFileName(
            self,
            "Zapisz obraz jako",
            str(suggested_path),
            ImageSaver.file_dialog_filter(),
        )

        if not filename:
            return False

        if not ImageSaver.can_save(filename):
            QMessageBox.warning(
                self,
                "Nieobsługiwany format",
                (
                    "Nie można zapisać obrazu w tym formacie.\n\n"
                    "Formaty RAW, takie jak NEF, są tylko do odczytu.\n"
                    "Wybierz JPG, PNG, WebP, BMP lub TIFF."
                ),
            )
            return False

        if self.canvas.save_image(filename):
            self._save_target_created = True
            self._update_status_bar()
            self.status_bar.set_message("Obraz zapisany")
            return True

        QMessageBox.warning(
            self,
            "Photo Editor 2.0",
            "Nie udało się zapisać obrazu.",
        )
        return False

    def _suggest_save_path(self) -> Path:
        """Suggest a safe edited copy name."""

        document = self.canvas.document

        if document.file_path is None:
            return Path("image_edited.jpg")

        source = Path(document.file_path)
        suffix = source.suffix.lower()

        if not ImageSaver.can_save(source):
            suffix = ".jpg"

        return source.with_name(
            f"{source.stem}_edited{suffix}"
        )

    def _handle_image_loaded(self) -> None:
        """Reset safe-save state after loading an original image."""

        self._save_target_created = False
        self._update_status_bar()

    def _adjust_image(self) -> None:
        """Open adjustments dialog with live preview."""

        if (
            not self.canvas.document.is_loaded
            or self.canvas.document.active_image is None
        ):
            return

        original_image = self.canvas.document.active_image.copy()
        dialog = AdjustmentsDialog(self)
        self._adjustments_dialog = dialog

        preview_timer = QTimer(dialog)
        preview_timer.setSingleShot(True)
        preview_timer.setInterval(40)

        def update_preview() -> None:
            settings = AdjustmentSettings(
                exposure=dialog.exposure,
                gamma=dialog.gamma,
                highlights=dialog.highlights,
                shadows=dialog.shadows,
                whites=dialog.whites,
                blacks=dialog.blacks,
                brightness=dialog.brightness,
                contrast=dialog.contrast,
                saturation=dialog.saturation,
                temperature=dialog.temperature,
                tint=dialog.tint,
            )

            self.canvas.preview_adjustments(
                original_image,
                settings,
            )

        def schedule_preview(
            exposure: int,
            gamma: int,
            highlights: int,
            shadows: int,
            whites: int,
            blacks: int,
            brightness: int,
            contrast: int,
            saturation: int,
            temperature: int,
            tint: int,
        ) -> None:
            preview_timer.start()

        def accept_adjustments() -> None:
            preview_timer.stop()
            self.canvas._restore_image(original_image)

            settings = AdjustmentSettings(
                exposure=dialog.exposure,
                gamma=dialog.gamma,
                highlights=dialog.highlights,
                shadows=dialog.shadows,
                whites=dialog.whites,
                blacks=dialog.blacks,
                brightness=dialog.brightness,
                contrast=dialog.contrast,
                saturation=dialog.saturation,
                temperature=dialog.temperature,
                tint=dialog.tint,
            )

            self.canvas.apply_adjustments(
                settings,
            )

            self.canvas.fit_to_window()
            self._adjustments_dialog = None

        def cancel_adjustments() -> None:
            preview_timer.stop()
            self.canvas._restore_image(original_image)
            self.canvas.fit_to_window()
            self._adjustments_dialog = None

        dialog.values_changed.connect(schedule_preview)
        preview_timer.timeout.connect(update_preview)
        dialog.accepted.connect(accept_adjustments)
        dialog.rejected.connect(cancel_adjustments)

        dialog.show()

    def _resize_image(self) -> None:
        """Open the image resize dialog and resize the image."""

        document = self.canvas.document

        if not document.is_loaded:
            return

        dialog = ResizeImageDialog(
            document.width,
            document.height,
            self,
        )

        if not dialog.exec():
            return

        if self.canvas.resize_image(
            dialog.image_width,
            dialog.image_height,
        ):
            self._update_status_bar()

    def _handle_crop_action_toggled(
        self,
        enabled: bool,
    ) -> None:
        if enabled:
            self.canvas.set_crop_selection_enabled(True)
            return

        if (
            self.canvas.crop_selection_enabled
            and self.canvas.crop_tool.has_selection
        ):
            if self.canvas.apply_crop():
                return

        self.canvas.set_crop_selection_enabled(False)

    def _update_status_bar(self) -> None:
        document = self.canvas.document

        self.status_bar.set_file_name(
            document.file_name
        )
        self.status_bar.set_image_size(
            document.width,
            document.height,
        )
        self.status_bar.set_message(
            "Obraz załadowany"
        )

    def _update_history_actions(
        self,
        can_undo: bool,
        can_redo: bool,
    ) -> None:
        self.actions.undo.setEnabled(can_undo)
        self.actions.redo.setEnabled(can_redo)

    def closeEvent(self, event) -> None:
        """Handle application closing."""

        if not self._confirm_discard_changes():
            event.ignore()
            return

        event.accept()